import json,os,pathlib,subprocess,tempfile,hashlib
out=pathlib.Path('/tmp/daft-crc-chunk-20260918'); builds=json.loads((out/'builds.json').read_text())
trace=out/'syscalls';trace.mkdir(exist_ok=False)
(trace/'manifest.json').write_text(json.dumps({'samples_per_job':1,'warmups_per_job':1,'case':'stream-wide','concurrency':8,'compression':'none','retries':6,'cpu_set':'2,3','builds':builds,'purpose':'deterministic syscall counts; traced timings are not acceptance','trace':['pwrite64','lseek'],'stat_time':'summed syscall wall time across threads, not elapsed query time'},indent=2)+'\n')
for disk,parent in [('local','/tmp'),('juicefs','/hdd-01/dev/qi.f')]:
 for variant in ['whole','512k','256k']:
  binary=builds[variant]['path']; assert hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest()==builds[variant]['sha256']
  with tempfile.TemporaryDirectory(prefix='daft-crc-syscalls-',dir=parent) as root:
   env={**os.environ,'TMPDIR':root,'RAYON_NUM_THREADS':'2','OMP_NUM_THREADS':'1','DAFT_WRITE_CASE':'stream-wide','DAFT_WRITE_CONCURRENCY':'8','DAFT_WRITE_COMPRESSION':'none','DAFT_WRITE_RETRIES':'6','DAFT_WRITE_SAMPLES':'1'}
   name=disk+'-'+variant
   cmd=['strace','-f','-qq','-c','-w','-e','trace=pwrite64,lseek','-o',str(trace/(name+'.txt')),'taskset','-c','2,3',binary,'bench_shuffle_writes','--ignored','--nocapture','--test-threads=1']
   with (trace/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
   assert not list(pathlib.Path(root).iterdir())
   print(name,(trace/(name+'.txt')).read_text(),flush=True)
