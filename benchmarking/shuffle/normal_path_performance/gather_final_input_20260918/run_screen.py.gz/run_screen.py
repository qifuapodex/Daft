"""Predeclared three-version Gather screen, diagnostic, not release acceptance."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

REPO = Path('/root/.paseo/worktrees/3hkin7e8/silly-mantis')
sys.path.insert(0, str(REPO / 'benchmarking/shuffle'))
from message_buffers_stats import summarize
from min_median_stats import analyze
from storage_abba import load_snapshot
import ray
from ray.cluster_utils import Cluster

OUT = Path('/tmp/daft-gather-final-20260918/screen')
CYCLES, SAMPLES = 4, 4
WHEELS = {
    'old': Path('/tmp/daft-p3-wheels/pre-eio/daft-0.3.0.dev0-cp310-abi3-manylinux_2_39_x86_64.whl'),
    'current': Path('/tmp/daft-task-handle-20260917/wheels/daft-0.3.0.dev0-cp310-abi3-manylinux_2_39_x86_64.whl'),
    'final': Path('/tmp/daft-gather-final-20260918/wheels/daft-0.3.0.dev0-cp310-abi3-manylinux_2_39_x86_64.whl'),
}
ROOTS = {'local': '/tmp', 'juicefs': '/hdd-01/dev/qi.f'}
# Each version and disk forms the same nested, symmetric order in every cycle.
HALF = [(disk, version) for disk in ROOTS for version in WHEELS]
ORDER = HALF + HALF[::-1]

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    OUT.mkdir(exist_ok=False)
    builds = {}
    packages = {}
    for version, wheel in WHEELS.items():
        package = OUT / 'packages' / version
        with zipfile.ZipFile(wheel) as z:
            z.extractall(package)
        extension, = (package / 'daft').glob('daft*.so')
        packages[version] = package
        builds[version] = {'wheel': str(wheel), 'wheel_sha256': sha(wheel), 'extension_sha256': sha(extension)}
    workload = REPO / 'benchmarking/shuffle/flight_gather_collect.py'
    source_files = subprocess.check_output(['git', 'ls-files', 'src', 'Cargo.toml', 'Cargo.lock', 'pyproject.toml'], cwd=REPO, text=True).splitlines()
    source = {p: sha(REPO / p) for p in source_files if (REPO / p).is_file()}
    save(OUT / 'source.json', source)
    save(OUT / 'manifest.json', {'cycles': CYCLES, 'samples_per_job': SAMPLES, 'warmups_per_job': 1, 'order': ORDER, 'compression': 'none', 'cpu_affinity': sorted(os.sched_getaffinity(0)), 'roots': ROOTS, 'builds': builds, 'acceptance': False, 'workload_sha256': sha(workload), 'runner_sha256': sha(__file__), 'source_base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'started': time.time()})
    env = {**os.environ, 'RAYON_NUM_THREADS': '2', 'OMP_NUM_THREADS': '1', 'DAFT_PROGRESS_BAR': '0', 'RAY_USAGE_STATS_ENABLED': '0'}
    os.environ.update(env)
    cluster = Cluster(initialize_head=True, connect=False, head_node_args={'num_cpus': 0, 'include_dashboard': False, 'object_store_memory': 256*1024**2})
    events = []
    expected_environment = None
    try:
        for _ in range(2):
            cluster.add_node(num_cpus=4, object_store_memory=4*1024**3)
        cluster.wait_for_nodes()
        for cycle in range(CYCLES):
            for position, (disk, version) in enumerate(ORDER):
                name = f'{cycle:02d}-{position:02d}-{disk}-{version}'
                before = load_snapshot()
                with (OUT / (name + '.log')).open('w') as log:
                    subprocess.run([sys.executable, str(workload), '--label', version, '--case', 'flight-gather', '--samples', str(SAMPLES), '--compression', 'none', '--root', ROOTS[disk], '--address', cluster.address], cwd=OUT, env={**env, 'PYTHONPATH': str(packages[version])}, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=300)
                records = [json.loads(line) for line in (OUT / (name + '.log')).read_text().splitlines() if line.startswith('{')]
                samples = [r for r in records if r['event'] == 'sample']
                assert len(samples) == SAMPLES + 1 and sum(r['warmup'] for r in samples) == 1
                assert all(r['oracle'] == 'PASS' and not r['profiled'] for r in samples)
                assert [r['spilled_bytes'] for r in records if r['event'] == 'object_store'] == [0]
                environment = next(r for r in records if r['event'] == 'environment')
                assert environment['extension_sha256'] == builds[version]['extension_sha256']
                assert all(w['extension_sha256'] == builds[version]['extension_sha256'] for w in environment['workers'])
                invariant = {'nodes': sorted(environment['nodes'], key=lambda n: n['id']), 'workers': [{k: v for k,v in w.items() if k != 'extension_sha256'} for w in environment['workers']]}
                if expected_environment is None:
                    expected_environment = invariant
                assert invariant == expected_environment, 'node resources/affinity/quotas/dependencies changed'
                records += [{'event': 'host_load', 'before': before, 'after': load_snapshot()}]
                with (OUT / 'events.jsonl').open('a') as f:
                    for r in records:
                        event = {**r, 'cycle': cycle, 'position': position, 'disk': disk, 'version': version}
                        events.append(event)
                        f.write(json.dumps(event) + '\n')
                print('PASS', name, flush=True)
    finally:
        ray.shutdown()
        cluster.shutdown()
    assert all(sha(REPO / p) == digest for p,digest in source.items())
    assert sha(workload) == json.loads((OUT/'manifest.json').read_text())['workload_sha256']
    for version,wheel in WHEELS.items():
        assert sha(wheel) == builds[version]['wheel_sha256']
    views = {}
    for disk in ROOTS:
        for baseline in ['old', 'current']:
            positions = [i for i,(d,v) in enumerate(ORDER) if d == disk and v in [baseline, 'final']]
            selected = [{**e, 'label': 'baseline' if e['version'] == baseline else 'candidate', 'position': positions.index(e['position'])} for e in events if e['disk'] == disk and e['version'] in [baseline, 'final']]
            summary = summarize(selected)
            views[disk + '-' + baseline] = analyze(selected, summary)
    save(OUT / 'summary.json', views)
    save(OUT / 'complete.json', {'jobs': CYCLES*len(ORDER), 'formal_samples': CYCLES*len(ORDER)*SAMPLES, 'warmups': CYCLES*len(ORDER), 'source_hashes_checked': len(source), 'all_oracles': 'PASS', 'finished': time.time()})
    print(json.dumps(views), flush=True)

if __name__ == '__main__':
    main()
