import hashlib, json, os, pathlib, shutil, subprocess, tempfile
out = pathlib.Path('/tmp/daft-gather-final-20260918')
rows = [json.loads(line) for line in (out/'build.jsonl').read_text().splitlines()]
assert rows[-1]['success']
builds = {}
for row in rows:
    if row.get('executable'):
        name = row['target']['name']
        binary = out/name
        shutil.copy2(row['executable'], binary)
        builds[name] = {'path':str(binary), 'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(), 'profile':row['profile']}
(out/'builds.json').write_text(json.dumps(builds, indent=2)+'\n')
for name,binary in builds.items():
    with (out/(name+'-tests.log')).open('w') as log:
        subprocess.run([binary['path'], *(['shuffle_file::'] if name=='daft_io' else []), '--test-threads=1'], stdout=log, stderr=subprocess.STDOUT, check=True)
    print(name, 'PASS', flush=True)
tests = [('daft_writers', 'cancelled_write_poisoning_survives_close_and_reuse'), ('daft_writers', 'cancelled_buffered_close_poisoning_survives_reuse'), ('daft_writers', 'cancelled_final_write_poisoning_survives_reuse'), ('daft_shuffles', 'shared_write_tracking_survives_cancellation'), ('daft_shuffles', 'deferred_close_keeps_write_tracking_until_cancelled_io_finishes'), ('daft_shuffles', 'final_partition_keeps_tracking_until_cancelled_io_finishes')]
for package,test in tests:
    with tempfile.TemporaryDirectory(prefix='daft-gather-final-cancel-') as root:
        env = {**os.environ, 'LD_PRELOAD':'/tmp/daft-shuffle-latest-20260917-kb48m9pn/inject.so', 'DAFT_TEST_SHUFFLE_IO_ROOT':root, 'DAFT_TEST_SHUFFLE_IO_OPERATION':'write', 'DAFT_TEST_SHUFFLE_IO_FAILURES':'100', 'DAFT_TEST_SHUFFLE_IO_ERRNO':'5'}
        with (out/(test+'.log')).open('w') as log:
            subprocess.run([builds[package]['path'], test, '--ignored', '--test-threads=1'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        assert list(pathlib.Path(root).glob('fault-*'))
    print(test, 'PASS', flush=True)
